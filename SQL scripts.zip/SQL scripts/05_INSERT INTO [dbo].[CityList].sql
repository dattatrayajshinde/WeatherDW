USE [Demo]
GO

INSERT INTO [dbo].[CityList]
           ([Id]
           ,[Name])

VALUES(1, 'London'),(2,'Aberporth'),(3,'Armagh'),(4,'Ballypatrick'),(5,'Bradford'),(6,'Braemar')
GO


