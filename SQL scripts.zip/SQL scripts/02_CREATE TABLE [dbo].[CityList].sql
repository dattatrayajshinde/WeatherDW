USE [Demo]
GO

/****** Object:  Table [dbo].[CityList]    Script Date: 9/22/2019 6:00:51 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CityList](
	[Id] [int] NULL,
	[Name] [varchar](200) NULL
) ON [PRIMARY]
GO


