USE [Demo]
GO

/****** Object:  Table [dbo].[WeatherForecast]    Script Date: 9/22/2019 6:02:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[WeatherForecast](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SymbolVar] [varchar](50) NULL,
	[SymbolName] [varchar](50) NULL,
	[CityName] [varchar](50) NULL,
	[HumidityValue] [varchar](50) NULL,
	[TemperatureUnit] [varchar](50) NULL,
	[TemperatureMax] [varchar](50) NULL,
	[TemperatureMin] [varchar](50) NULL,
	[HumidityUnit] [varchar](50) NULL,
	[TemperatureAvg] [varchar](50) NULL,
	[WindSpeedName] [varchar](50) NULL,
	[WindSpeedValue] [varchar](50) NULL,
	[PressureUnit] [varchar](50) NULL,
	[PressureValue] [varchar](50) NULL,
	[CloudValue] [varchar](50) NULL,
	[WindDirectionName] [varchar](50) NULL,
	[PrecipitationValue] [varchar](50) NULL,
	[PrecipitationUnit] [varchar](50) NULL,
	[PrecipitationMode] [varchar](50) NULL,
	[CloudName] [varchar](50) NULL,
	[WindDirectionCode] [varchar](50) NULL,
	[WindDirectionValue] [varchar](50) NULL,
	[TimeTo] [varchar](50) NULL,
	[TimeFrom] [varchar](50) NULL
) ON [PRIMARY]
GO


