USE [Demo]
GO

/****** Object:  Table [dbo].[Weather]    Script Date: 9/22/2019 6:01:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Weather](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InsertDate] [varchar](255) NULL,
	[CityID] [varchar](255) NULL,
	[CityName] [varchar](255) NULL,
	[CoordLong] [varchar](255) NULL,
	[CoordLat] [varchar](255) NULL,
	[Country] [varchar](255) NULL,
	[SunriseStart] [varchar](255) NULL,
	[SunriseSet] [varchar](255) NULL,
	[TemperatureAvg] [varchar](255) NULL,
	[TemperatureMin] [varchar](255) NULL,
	[TemperatureMax] [varchar](255) NULL,
	[TemperatureUnit] [varchar](255) NULL,
	[HumidityValue] [varchar](255) NULL,
	[HumidityUnit] [varchar](255) NULL,
	[PressureValue] [varchar](255) NULL,
	[PressureUnit] [varchar](255) NULL,
	[WindSpeedValue] [varchar](255) NULL,
	[WindSpeedName] [varchar](255) NULL,
	[WindDirectionValue] [varchar](255) NULL,
	[WindDirectionCode] [varchar](255) NULL,
	[WindDirectionName] [varchar](255) NULL,
	[CloudValue] [varchar](255) NULL,
	[CloudName] [varchar](255) NULL,
	[PrecipitationMode] [varchar](255) NULL,
	[WeatherNumber] [varchar](255) NULL,
	[WeatherValue] [varchar](255) NULL,
	[WeatherIcon] [varchar](255) NULL,
	[LastUpdateValue] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Weather] ADD  CONSTRAINT [df_weather_Idate]  DEFAULT (getdate()) FOR [InsertDate]
GO


